import React, { useState } from 'react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, Legend 
} from 'recharts';
import { useQuery } from '@tanstack/react-query';
import { 
  getBoards, getDailyReports, getMonthlyReports, 
  getInterfaceReports, getPPPoEReports, getHotspotReports, 
  exportReport 
} from '../services/api';
import { FileText, Activity, Users, Download, Wifi, Network } from 'lucide-react';
import toast from 'react-hot-toast';
import LoadingSpinner from '../components/ui/LoadingSpinner';

function SizedContainer({ heightClass = "h-64", children }) {
  const ref = React.useRef(null);
  const [size, setSize] = React.useState({ w: 0, h: 0 });

  React.useLayoutEffect(() => {
    if (!ref.current) return;
    const measure = () => {
      const rect = ref.current.getBoundingClientRect();
      const w = Math.max(0, Math.floor(rect.width));
      const h = Math.max(0, Math.floor(rect.height));
      setSize({ w, h });
    };
    measure();
    const ro = new ResizeObserver(() => {
      measure();
    });
    ro.observe(ref.current);
    return () => ro.disconnect();
  }, []);

  const ready = size.w > 0 && size.h > 0;
  const childWithKey = React.isValidElement(children)
    ? React.cloneElement(children, { key: `${size.w}x${size.h}` })
    : children;

  return (
    <div ref={ref} className={`${heightClass} w-full`}>
      {ready ? (
        childWithKey
      ) : (
        <div className="h-full w-full bg-gray-100 rounded animate-pulse" />
      )}
    </div>
  );
}

const Reports = () => {
  const [selectedBoard, setSelectedBoard] = useState('');
  const [period, setPeriod] = useState('daily'); // 'daily' or 'monthly'
  const [activeTab, setActiveTab] = useState('summary'); // 'summary', 'interfaces', 'pppoe', 'hotspot'
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Fetch boards
  const { 
    data: boards = [], 
    isLoading: isBoardsLoading, 
    isError: isBoardsError 
  } = useQuery({
    queryKey: ['boards'],
    queryFn: () => getBoards(),
  });

  // Effect to set default selected board
  React.useEffect(() => {
    if (boards && boards.length > 0 && !selectedBoard) {
      setSelectedBoard(boards[0].board_id);
    }
  }, [boards, selectedBoard]);

  // Effect to show error toast
  React.useEffect(() => {
    if (isBoardsError) {
      toast.error("Failed to load devices list");
    }
  }, [isBoardsError]);

  // Fetch reports
  const { 
    data: reportData = [], 
    isLoading,
    isError: isReportsError 
  } = useQuery({
    queryKey: ['reports', selectedBoard, activeTab, period, startDate, endDate],
    queryFn: async () => {
      if (!selectedBoard) return [];
      
      let result = [];
      try {
        if (activeTab === 'summary') {
            if (period === 'daily') {
                result = await getDailyReports(selectedBoard, 30, startDate || null, endDate || null);
            } else {
                result = await getMonthlyReports(selectedBoard, 12, startDate || null, endDate || null);
            }
        } else if (activeTab === 'interfaces') {
            result = await getInterfaceReports(selectedBoard, 100, startDate || null, endDate || null);
        } else if (activeTab === 'pppoe') {
            result = await getPPPoEReports(selectedBoard, 100, startDate || null, endDate || null);
        } else if (activeTab === 'hotspot') {
            result = await getHotspotReports(selectedBoard, 100, startDate || null, endDate || null);
        }
      } catch (error) {
        console.error("Failed to fetch reports", error);
        throw error;
      }
      
      // Sort data by date ascending
      const sortedData = [...result].sort((a, b) => {
        const dateA = new Date(a.log_date || a.log_month);
        const dateB = new Date(b.log_date || b.log_month);
        return dateA - dateB;
      });

      // Formatting
      return sortedData.map(item => {
          const dateObj = new Date(item.log_date || item.log_month);
          const displayDate = activeTab === 'summary' && period === 'monthly'
              ? dateObj.toLocaleDateString(undefined, { year: 'numeric', month: 'short' })
              : dateObj.toLocaleDateString();
          
          return {
              ...item,
              displayDate,
          };
      });
    },
    enabled: !!selectedBoard,
  });

  // Effect to show reports error toast
  React.useEffect(() => {
    if (isReportsError) {
      toast.error("Failed to load report data");
    }
  }, [isReportsError]);

  const handleExport = async (format) => {
    if (activeTab !== 'summary') {
        toast.error("Export currently supported only for Summary tab");
        return;
    }
    
    try {
      const response = await exportReport(
        selectedBoard, 
        period, 
        format, 
        period === 'daily' ? 30 : 12, 
        startDate || null, 
        endDate || null
      );
      
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      const filename = `${period}_report_${selectedBoard}_${new Date().toISOString().split('T')[0]}.${format}`;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.parentNode.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      toast.success(`Report exported as ${format.toUpperCase()}`);
    } catch (error) {
      console.error("Export failed", error);
      toast.error("Failed to export report");
    }
  };

  const renderSummaryCharts = () => (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-white p-4 rounded-lg shadow">
        <h3 className="text-lg font-semibold mb-4 text-gray-700">Traffic Overview (MB)</h3>
        <SizedContainer heightClass="h-64">
          <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0} debounce={300}>
            <AreaChart data={reportData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="displayDate" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Area type="monotone" dataKey={activeTab === 'summary' && period === 'monthly' ? "total_download_bytes" : "avg_download"} name="Download" stackId="1" stroke="#3b82f6" fill="#3b82f6" />
              <Area type="monotone" dataKey={activeTab === 'summary' && period === 'monthly' ? "total_upload_bytes" : "avg_upload"} name="Upload" stackId="1" stroke="#10b981" fill="#10b981" />
            </AreaChart>
          </ResponsiveContainer>
        </SizedContainer>
      </div>

      <div className="bg-white p-4 rounded-lg shadow">
        <h3 className="text-lg font-semibold mb-4 text-gray-700">Resource Usage</h3>
        <SizedContainer heightClass="h-64">
          <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0} debounce={300}>
            <LineChart data={reportData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="displayDate" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="avg_cpu_load" name="CPU Load (%)" stroke="#ef4444" />
              <Line type="monotone" dataKey="max_cpu_load" name="Max CPU (%)" stroke="#b91c1c" strokeDasharray="5 5" />
            </LineChart>
          </ResponsiveContainer>
        </SizedContainer>
      </div>
    </div>
  );

  const renderTable = (columns) => (
    <div className="bg-white shadow overflow-hidden rounded-lg">
        <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
                <tr>
                    {columns.map((col, idx) => (
                        <th key={idx} className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            {col.label}
                        </th>
                    ))}
                </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
                {reportData.map((row, idx) => (
                    <tr key={idx}>
                        {columns.map((col, cIdx) => (
                            <td key={cIdx} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {col.render ? col.render(row) : row[col.key]}
                            </td>
                        ))}
                    </tr>
                ))}
                {reportData.length === 0 && (
                    <tr>
                        <td colSpan={columns.length} className="px-6 py-4 text-center text-gray-500">
                            No data available
                        </td>
                    </tr>
                )}
            </tbody>
        </table>
    </div>
  );

  return (
    <div className="space-y-6 p-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <FileText className="w-8 h-8 text-blue-600" />
            System Reports
          </h1>
          <p className="text-gray-500 text-sm mt-1">
             <span className="inline-flex items-center rounded-md bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 ring-1 ring-inset ring-blue-700/10 mr-2">
               Historical / Polled
             </span>
            Historical performance data and aggregated statistics
          </p>
        </div>
        <div className="flex gap-2">
            <button onClick={() => handleExport('csv')} className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors">
                <Download className="w-4 h-4" /> CSV
            </button>
            <button onClick={() => handleExport('pdf')} className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors">
                <Download className="w-4 h-4" /> PDF
            </button>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white p-4 rounded-lg shadow mb-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Select Device</label>
            <select
              value={selectedBoard}
              onChange={(e) => setSelectedBoard(e.target.value)}
              disabled={isBoardsLoading || isBoardsError || boards.length === 0}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100 disabled:text-gray-500"
            >
              {isBoardsLoading && <option>Loading devices...</option>}
              {isBoardsError && <option>Error loading devices</option>}
              {!isBoardsLoading && !isBoardsError && boards.length === 0 && <option value="">No devices found</option>}
              {!isBoardsLoading && !isBoardsError && boards.length > 0 && boards.map((board) => (
                <option key={board.board_id} value={board.board_id}>
                  {board.board_name || board.name} ({board.ip_address || board.host})
                </option>
              ))}
            </select>
          </div>

          {activeTab === 'summary' && (
             <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Report Period</label>
                <div className="flex border border-gray-300 rounded-md overflow-hidden">
                <button
                    className={`flex-1 py-2 text-sm font-medium transition-colors ${period === 'daily' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-50'}`}
                    onClick={() => setPeriod('daily')}
                >
                    Daily
                </button>
                <button
                    className={`flex-1 py-2 text-sm font-medium transition-colors ${period === 'monthly' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-50'}`}
                    onClick={() => setPeriod('monthly')}
                >
                    Monthly
                </button>
                </div>
            </div>
          )}
          
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">Date Range (Optional)</label>
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full border border-gray-300 rounded-md px-2 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <span className="text-gray-400">-</span>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full border border-gray-300 rounded-md px-2 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                onClick={() => { setStartDate(''); setEndDate(''); }}
                className="px-3 py-2 bg-gray-100 text-gray-600 rounded-md hover:bg-gray-200 transition-colors text-sm font-medium whitespace-nowrap"
                title="Show all periods"
              >
                All Period
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="-mb-px flex space-x-8">
            {[
                { id: 'summary', label: 'Summary', icon: Activity },
                { id: 'interfaces', label: 'Interfaces', icon: Network },
                { id: 'pppoe', label: 'PPPoE Usage', icon: Users },
                { id: 'hotspot', label: 'Hotspot Usage', icon: Wifi },
            ].map((tab) => (
                <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`
                        flex items-center whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors
                        ${activeTab === tab.id
                            ? 'border-blue-500 text-blue-600'
                            : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                        }
                    `}
                >
                    <tab.icon className={`mr-2 h-5 w-5 ${activeTab === tab.id ? 'text-blue-500' : 'text-gray-400'}`} />
                    {tab.label}
                </button>
            ))}
        </nav>
      </div>

      {/* Content */}
      {isLoading ? (
        <div className="flex justify-center py-12">
            <LoadingSpinner />
        </div>
      ) : (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            {activeTab === 'summary' && renderSummaryCharts()}
            
            {activeTab === 'interfaces' && renderTable([
                { label: 'Date', key: 'displayDate' },
                { label: 'Interface', key: 'interface_name' },
                { label: 'Total Download', key: 'total_rx_bytes', render: (row) => `${(row.total_rx_bytes / 1024 / 1024).toFixed(2)} MB` },
                { label: 'Total Upload', key: 'total_tx_bytes', render: (row) => `${(row.total_tx_bytes / 1024 / 1024).toFixed(2)} MB` },
            ])}
            
            {activeTab === 'pppoe' && renderTable([
                 { label: 'Date', key: 'displayDate' },
                 { label: 'Username', key: 'pppoe_username' },
                 { label: 'Total Download', key: 'download_bytes', render: (row) => `${(row.download_bytes / 1024 / 1024).toFixed(2)} MB` },
                 { label: 'Total Upload', key: 'upload_bytes', render: (row) => `${(row.upload_bytes / 1024 / 1024).toFixed(2)} MB` },
            ])}

            {activeTab === 'hotspot' && renderTable([
                 { label: 'Date', key: 'displayDate' },
                 { label: 'Username', key: 'username' },
                 { label: 'Total Download', key: 'daily_download', render: (row) => `${(row.daily_download / 1024 / 1024).toFixed(2)} MB` },
                 { label: 'Total Upload', key: 'daily_upload', render: (row) => `${(row.daily_upload / 1024 / 1024).toFixed(2)} MB` },
            ])}
        </div>
      )}
    </div>
  );
};

export default Reports;

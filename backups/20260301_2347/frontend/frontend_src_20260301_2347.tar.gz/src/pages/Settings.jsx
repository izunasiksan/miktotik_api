import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { telegramService } from '../services/telegramService';
import { toast } from 'react-hot-toast';
import { Plus, Trash2, Edit2, Check, X, Shield, ShieldAlert, Bot, User } from 'lucide-react';
import LoadingSpinner from '../components/ui/LoadingSpinner';

const Settings = () => {
  const [activeTab, setActiveTab] = useState('bots');

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6 text-gray-800">System Settings</h1>
      
      <div className="flex border-b border-gray-200 mb-6">
        <button
          className={`py-2 px-4 font-medium transition-colors duration-200 ${
            activeTab === 'bots'
              ? 'border-b-2 border-blue-500 text-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
          onClick={() => setActiveTab('bots')}
        >
          Telegram Bots
        </button>
        <button
          className={`py-2 px-4 font-medium transition-colors duration-200 ${
            activeTab === 'recipients'
              ? 'border-b-2 border-blue-500 text-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
          onClick={() => setActiveTab('recipients')}
        >
          Telegram Recipients
        </button>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        {activeTab === 'bots' ? <BotsManager /> : <RecipientsManager />}
      </div>
    </div>
  );
};

const BotsManager = () => {
  const queryClient = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [editingBot, setEditingBot] = useState(null);
  const [formData, setFormData] = useState({ bot_name: '', bot_token: '', is_active: true });

  const { data: bots = [], isLoading, isError } = useQuery({
    queryKey: ['bots'],
    queryFn: telegramService.getBots,
  });

  React.useEffect(() => {
    if (isError) {
      toast.error('Failed to fetch bots');
    }
  }, [isError]);

  const createMutation = useMutation({
    mutationFn: telegramService.createBot,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bots'] });
      toast.success('Bot created successfully');
      setShowModal(false);
      resetForm();
    },
    onError: () => toast.error('Operation failed')
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => telegramService.updateBot(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bots'] });
      toast.success('Bot updated successfully');
      setShowModal(false);
      resetForm();
    },
    onError: () => toast.error('Operation failed')
  });

  const deleteMutation = useMutation({
    mutationFn: telegramService.deleteBot,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bots'] });
      toast.success('Bot deleted');
    },
    onError: () => toast.error('Failed to delete bot')
  });

  const resetForm = () => {
    setEditingBot(null);
    setFormData({ bot_name: '', bot_token: '', is_active: true });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingBot) {
      updateMutation.mutate({ id: editingBot.bot_id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleDelete = (id) => {
    if (window.confirm('Are you sure?')) {
      deleteMutation.mutate(id);
    }
  };

  const openEdit = (bot) => {
    setEditingBot(bot);
    setFormData({ bot_name: bot.bot_name, bot_token: bot.bot_token, is_active: bot.is_active });
    setShowModal(true);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold flex items-center gap-2">
          <Bot className="w-5 h-5" /> Managed Bots
        </h2>
        <button
          onClick={() => {
            resetForm();
            setShowModal(true);
          }}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700"
        >
          <Plus className="w-4 h-4" /> Add Bot
        </button>
      </div>

      {isLoading ? (
        <LoadingSpinner />
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Token (Masked)</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {bots.map((bot) => (
                <tr key={bot.bot_id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{bot.bot_name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {bot.bot_token ? `${bot.bot_token.substring(0, 5)}...${bot.bot_token.slice(-5)}` : '******'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${bot.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                      {bot.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button onClick={() => openEdit(bot)} className="text-indigo-600 hover:text-indigo-900 mr-4">
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button onClick={() => handleDelete(bot.bot_id)} className="text-red-600 hover:text-red-900">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
              {bots.length === 0 && (
                <tr>
                  <td colSpan="4" className="px-6 py-4 text-center text-gray-500">No bots found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-bold mb-4">{editingBot ? 'Edit Bot' : 'Add New Bot'}</h3>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700">Bot Name</label>
                <input
                  type="text"
                  required
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2"
                  value={formData.bot_name}
                  onChange={(e) => setFormData({ ...formData, bot_name: e.target.value })}
                />
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700">Bot Token</label>
                <input
                  type="text"
                  required
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2"
                  value={formData.bot_token}
                  onChange={(e) => setFormData({ ...formData, bot_token: e.target.value })}
                />
                <p className="text-xs text-gray-500 mt-1">Found in BotFather</p>
              </div>
              <div className="mb-4 flex items-center">
                <input
                  type="checkbox"
                  id="isActive"
                  className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 mr-2"
                  checked={formData.is_active}
                  onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
                />
                <label htmlFor="isActive" className="text-sm font-medium text-gray-700">Active</label>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  {createMutation.isPending || updateMutation.isPending ? 'Saving...' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

const RecipientsManager = () => {
  const queryClient = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [editingRecipient, setEditingRecipient] = useState(null);
  const [formData, setFormData] = useState({
    chat_id: '',
    bot_id: '',
    alert_levels: ['critical'],
    is_active: true
  });

  const { data: recipients = [], isLoading: isLoadingRecipients, isError: isRecipientsError } = useQuery({
    queryKey: ['recipients'],
    queryFn: telegramService.getRecipients,
  });

  const { data: bots = [], isLoading: isLoadingBots, isError: isBotsError } = useQuery({
    queryKey: ['bots'],
    queryFn: telegramService.getBots,
  });

  React.useEffect(() => {
    if (isRecipientsError) {
      toast.error('Failed to fetch recipients');
    }
  }, [isRecipientsError]);

  React.useEffect(() => {
    if (isBotsError) {
      toast.error('Failed to fetch bots');
    }
  }, [isBotsError]);

  const createMutation = useMutation({
    mutationFn: telegramService.createRecipient,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recipients'] });
      toast.success('Recipient added');
      setShowModal(false);
      resetForm();
    },
    onError: () => toast.error('Operation failed')
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => telegramService.updateRecipient(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recipients'] });
      toast.success('Recipient updated');
      setShowModal(false);
      resetForm();
    },
    onError: () => toast.error('Operation failed')
  });

  const deleteMutation = useMutation({
    mutationFn: telegramService.deleteRecipient,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recipients'] });
      toast.success('Recipient deleted');
    },
    onError: () => toast.error('Failed to delete recipient')
  });

  const resetForm = () => {
    setEditingRecipient(null);
    setFormData({
      chat_id: '',
      bot_id: bots.length > 0 ? bots[0].bot_id : '',
      alert_levels: ['critical'],
      is_active: true
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const payload = {
      ...formData,
      chat_id: parseInt(formData.chat_id),
      bot_id: parseInt(formData.bot_id)
    };

    if (editingRecipient) {
      updateMutation.mutate({ id: editingRecipient.recipient_id, data: payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const handleDelete = (id) => {
    if (window.confirm('Are you sure?')) {
      deleteMutation.mutate(id);
    }
  };

  const openEdit = (recipient) => {
    setEditingRecipient(recipient);
    setFormData({
      chat_id: recipient.chat_id,
      bot_id: recipient.bot_id,
      alert_levels: recipient.alert_levels || [],
      is_active: recipient.is_active
    });
    setShowModal(true);
  };

  const toggleAlertLevel = (level) => {
    const currentLevels = formData.alert_levels;
    if (currentLevels.includes(level)) {
      setFormData({ ...formData, alert_levels: currentLevels.filter(l => l !== level) });
    } else {
      setFormData({ ...formData, alert_levels: [...currentLevels, level] });
    }
  };

  const isLoading = isLoadingRecipients || isLoadingBots;

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold flex items-center gap-2">
          <User className="w-5 h-5" /> Alert Recipients
        </h2>
        <button
          onClick={() => {
            resetForm();
            setShowModal(true);
          }}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700"
        >
          <Plus className="w-4 h-4" /> Add Recipient
        </button>
      </div>

      {isLoading ? (
        <LoadingSpinner />
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Chat ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Bot</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Alert Levels</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {recipients.map((recipient) => {
                const bot = bots.find(b => b.bot_id === recipient.bot_id);
                return (
                  <tr key={recipient.recipient_id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{recipient.chat_id}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{bot ? bot.bot_name : 'Unknown Bot'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div className="flex gap-1 flex-wrap">
                        {recipient.alert_levels?.map(level => (
                          <span key={level} className="px-2 py-0.5 rounded text-xs bg-gray-100 border border-gray-300">
                            {level}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${recipient.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                        {recipient.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button onClick={() => openEdit(recipient)} className="text-indigo-600 hover:text-indigo-900 mr-4">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button onClick={() => handleDelete(recipient.recipient_id)} className="text-red-600 hover:text-red-900">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
              {recipients.length === 0 && (
                <tr>
                  <td colSpan="5" className="px-6 py-4 text-center text-gray-500">No recipients found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-bold mb-4">{editingRecipient ? 'Edit Recipient' : 'Add New Recipient'}</h3>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700">Chat ID</label>
                <input
                  type="number"
                  required
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2"
                  value={formData.chat_id}
                  onChange={(e) => setFormData({ ...formData, chat_id: e.target.value })}
                />
                <p className="text-xs text-gray-500 mt-1">From user's Telegram ID</p>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700">Bot</label>
                <select
                  required
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2"
                  value={formData.bot_id}
                  onChange={(e) => setFormData({ ...formData, bot_id: e.target.value })}
                >
                  <option value="">Select a bot</option>
                  {bots.map(bot => (
                    <option key={bot.bot_id} value={bot.bot_id}>{bot.bot_name}</option>
                  ))}
                </select>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">Alert Levels</label>
                <div className="flex gap-2 flex-wrap">
                  {['info', 'warning', 'critical', 'resolved'].map(level => (
                    <button
                      type="button"
                      key={level}
                      onClick={() => toggleAlertLevel(level)}
                      className={`px-3 py-1 rounded-full text-sm border ${
                        formData.alert_levels.includes(level)
                          ? 'bg-blue-100 border-blue-500 text-blue-700'
                          : 'bg-gray-50 border-gray-300 text-gray-600'
                      }`}
                    >
                      {level}
                    </button>
                  ))}
                </div>
              </div>
              <div className="mb-4 flex items-center">
                <input
                  type="checkbox"
                  id="recipientActive"
                  className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 mr-2"
                  checked={formData.is_active}
                  onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
                />
                <label htmlFor="recipientActive" className="text-sm font-medium text-gray-700">Active</label>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  {createMutation.isPending || updateMutation.isPending ? 'Saving...' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Settings;

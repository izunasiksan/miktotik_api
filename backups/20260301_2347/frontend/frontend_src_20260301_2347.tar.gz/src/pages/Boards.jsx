import React, { useState } from 'react';
import { getBoards, deleteBoard, updateBoard, createBoard } from '../services/api';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { Plus, Search, Edit, Trash2, Shield, Download, ShieldAlert, Eye, Server } from 'lucide-react';
import Modal from '../components/Modal';
import VPNModal from '../components/VPNModal';
import BackupModal from '../components/BackupModal';
import RouterModal from '../components/forms/RouterModal';
import toast, { Toaster } from 'react-hot-toast';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import StatusBadge from '../components/ui/StatusBadge';
import LoadingSpinner from '../components/ui/LoadingSpinner';

const Boards = () => {
  const [search, setSearch] = useState('');
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isVPNModalOpen, setIsVPNModalOpen] = useState(false);
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);
  const [isRouterModalOpen, setIsRouterModalOpen] = useState(false);
  const [boardToDelete, setBoardToDelete] = useState(null);
  const [selectedBoard, setSelectedBoard] = useState(null);

  const queryClient = useQueryClient();

  const { data: boards = [], isLoading, isError } = useQuery({
    queryKey: ['boards'],
    queryFn: () => getBoards(),
  });

  const deleteMutation = useMutation({
    mutationFn: deleteBoard,
    onSuccess: () => {
      toast.success("Board deleted successfully");
      queryClient.invalidateQueries(['boards']);
      setIsDeleteModalOpen(false);
      setBoardToDelete(null);
    },
    onError: () => {
      toast.error("Failed to delete board");
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => updateBoard(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['boards']);
    },
    onError: () => {
      toast.error("Failed to update board");
    }
  });

  const createMutation = useMutation({
    mutationFn: createBoard,
    onSuccess: () => {
      toast.success("Router created successfully");
      queryClient.invalidateQueries(['boards']);
      setIsRouterModalOpen(false);
      setSelectedBoard(null);
    },
    onError: (error) => {
      toast.error(error.response?.data?.detail || "Failed to create router");
    }
  });

  const editMutation = useMutation({
    mutationFn: ({ id, data }) => updateBoard(id, data),
    onSuccess: () => {
      toast.success("Router updated successfully");
      queryClient.invalidateQueries(['boards']);
      setIsRouterModalOpen(false);
      setSelectedBoard(null);
    },
    onError: (error) => {
      toast.error(error.response?.data?.detail || "Failed to update router");
    }
  });

  const handleDeleteClick = (board) => {
    setBoardToDelete(board);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = () => {
    if (!boardToDelete) return;
    deleteMutation.mutate(boardToDelete.board_id);
  };

  const toggleMaintenance = (board) => {
    updateMutation.mutate({ 
      id: board.board_id, 
      data: { is_maintenance: !board.is_maintenance } 
    }, {
      onSuccess: () => {
        toast.success(`Maintenance mode ${!board.is_maintenance ? 'enabled' : 'disabled'}`);
      }
    });
  };

  const handleSaveRouter = (data) => {
    if (selectedBoard) {
      editMutation.mutate({ id: selectedBoard.board_id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const openAddModal = () => {
      setSelectedBoard(null);
      setIsRouterModalOpen(true);
  };

  const openEditModal = (board) => {
      setSelectedBoard(board);
      setIsRouterModalOpen(true);
  };

  if (isLoading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex h-[60vh] items-center justify-center flex-col gap-4">
        <p className="text-red-500">Failed to load boards</p>
        <Button onClick={() => queryClient.invalidateQueries(['boards'])}>Retry</Button>
      </div>
    );
  }

  const filteredBoards = boards.filter(board => 
    board.board_name.toLowerCase().includes(search.toLowerCase()) ||
    board.ip_address.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <Toaster position="top-right" />
      
      {/* Delete Confirmation Modal */}
      <Modal 
        isOpen={isDeleteModalOpen} 
        onClose={() => setIsDeleteModalOpen(false)} 
        title="Delete Device"
        size="sm"
      >
        <div className="mt-2">
          <p className="text-sm text-slate-500">
            Are you sure you want to delete <b>{boardToDelete?.board_name}</b>? This action cannot be undone.
          </p>
        </div>
        <div className="mt-6 flex justify-end gap-3">
          <Button variant="secondary" onClick={() => setIsDeleteModalOpen(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={confirmDelete}>
            Delete
          </Button>
        </div>
      </Modal>

      {/* Other Modals (Keep as is for now, assuming they use the new Modal component internally or update them later) */}
      <VPNModal 
        isOpen={isVPNModalOpen} 
        onClose={() => setIsVPNModalOpen(false)} 
        boardId={selectedBoard?.board_id}
        boardName={selectedBoard?.board_name}
      />

      <BackupModal 
        isOpen={isBackupModalOpen} 
        onClose={() => setIsBackupModalOpen(false)} 
        boardId={selectedBoard?.board_id}
        boardName={selectedBoard?.board_name}
      />

      <RouterModal
        isOpen={isRouterModalOpen}
        onClose={() => setIsRouterModalOpen(false)}
        onSave={handleSaveRouter}
        initialData={selectedBoard}
      />

      {/* Header & Actions */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
           <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Device Management</h1>
           <p className="text-slate-500 text-sm mt-1">Manage your Mikrotik routers and switches.</p>
        </div>
        <Button onClick={openAddModal}>
          <Plus className="w-4 h-4 mr-2" />
          Add Device
        </Button>
      </div>

      {/* Search & Filter */}
      <div className="flex items-center gap-4 bg-white p-4 rounded-xl shadow-sm border border-slate-200">
        <div className="relative flex-1 max-w-md">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-slate-400" />
            </div>
            <Input 
                type="text" 
                className="pl-10"
                placeholder="Search by name or IP..." 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
            />
        </div>
        {/* Add more filters here if needed */}
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-50">
              <tr>
                <th scope="col" className="px-6 py-4 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Device Info
                </th>
                <th scope="col" className="px-6 py-4 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Connection
                </th>
                <th scope="col" className="px-6 py-4 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-6 py-4 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Last Check
                </th>
                <th scope="col" className="relative px-6 py-4">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-200">
              {filteredBoards.length === 0 ? (
                    <tr>
                        <td colSpan="5" className="px-6 py-12 text-center text-slate-500">
                           <div className="flex flex-col items-center">
                             <Server className="w-12 h-12 text-slate-300 mb-3" />
                             <p>No devices found.</p>
                           </div>
                        </td>
                    </tr>
              ) : (
                  filteredBoards.map((board) => (
                    <tr key={board.board_id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="h-10 w-10 flex-shrink-0 rounded-lg bg-indigo-50 flex items-center justify-center">
                             <Server className="h-5 w-5 text-indigo-600" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-slate-900">{board.board_name}</div>
                            <div className="text-sm text-slate-500">{board.mikrotik_identity || '-'}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-slate-900 font-mono">{board.ip_address}</div>
                        <div className="text-xs text-slate-500 mt-0.5">Port: {board.port_api}</div>
                        <span className="inline-flex items-center mt-1 px-2 py-0.5 rounded text-xs font-medium bg-slate-100 text-slate-600">
                            {board.site_group}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                         <StatusBadge 
                            status={board.is_maintenance ? 'maintenance' : (board.is_online ? 'online' : 'offline')} 
                         />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                        {board.last_ping_at ? new Date(board.last_ping_at).toLocaleString() : 'Never'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex justify-end gap-2">
                            <button
                                className={`p-1.5 rounded-md transition-colors ${board.is_maintenance ? 'text-amber-600 bg-amber-50 hover:bg-amber-100' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'}`}
                                title="Toggle Maintenance"
                                onClick={() => toggleMaintenance(board)}
                            >
                                <ShieldAlert className="w-4 h-4" />
                            </button>
                            <button 
                                className="p-1.5 rounded-md text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
                                title="Manage VPN"
                                onClick={() => {
                                    setSelectedBoard(board);
                                    setIsVPNModalOpen(true);
                                }}
                            >
                                <Shield className="w-4 h-4" />
                            </button>
                            <button 
                                className="p-1.5 rounded-md text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 transition-colors"
                                title="Manage Backups"
                                onClick={() => {
                                    setSelectedBoard(board);
                                    setIsBackupModalOpen(true);
                                }}
                            >
                                <Download className="w-4 h-4" />
                            </button>
                            <Link 
                                to={`/boards/${board.board_id}`}
                                className="p-1.5 rounded-md text-slate-400 hover:text-teal-600 hover:bg-teal-50 transition-colors"
                                title="View Details"
                            >
                                <Eye className="w-4 h-4" />
                            </Link>
                            <button 
                                className="p-1.5 rounded-md text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                                onClick={() => openEditModal(board)}
                            >
                                <Edit className="w-4 h-4" />
                            </button>
                            <button 
                                className="p-1.5 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                                onClick={() => handleDeleteClick(board)}
                            >
                                <Trash2 className="w-4 h-4" />
                            </button>
                        </div>
                      </td>
                    </tr>
                  ))
              )}
            </tbody>
          </table>
        </div>
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200">
           <p className="text-xs text-slate-500">
              Showing {filteredBoards.length} devices
           </p>
        </div>
      </div>
    </div>
  );
};

export default Boards;

import React from 'react';
import { getDashboardSummary } from '../services/api';
import { useQuery } from '@tanstack/react-query';
import { Activity, Server, AlertCircle, CheckCircle, RefreshCcw, Wifi, Network, ShieldCheck, FileText } from 'lucide-react';
import StatCard from '../components/StatCard';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import toast, { Toaster } from 'react-hot-toast';
import LoadingSpinner from '../components/ui/LoadingSpinner';

const Dashboard = () => {
  const { data: stats, isLoading, isRefetching, refetch, error } = useQuery({
    queryKey: ['dashboardStats'],
    queryFn: getDashboardSummary,
    refetchInterval: 30000, // Poll every 30 seconds
  });

  if (isLoading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (error) {
     toast.error("Failed to load dashboard data");
  }

  const safeStats = stats || {
    total_boards: 0,
    online_boards: 0,
    offline_boards: 0,
    maintenance_boards: 0,
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <Toaster position="top-right" />
      
      {/* Header Section */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Dashboard Overview</h1>
          <p className="text-slate-500 text-sm mt-1">
            <span className="inline-flex items-center rounded-md bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 ring-1 ring-inset ring-blue-700/10 mr-2">
              Historical / Polled
            </span>
            Overview of your Mikrotik network infrastructure status.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button 
            variant="secondary" 
            size="sm" 
            onClick={() => refetch()} 
            isLoading={isRefetching}
          >
            <RefreshCcw className={`w-4 h-4 mr-2 ${isRefetching ? 'animate-spin' : ''}`} />
            Refresh Data
          </Button>
        </div>
      </div>
      
      {/* Stats Grid */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard 
          title="Total Devices" 
          value={safeStats.total_boards} 
          icon={Server} 
          color="bg-indigo-600" 
          trend="up"
          trendValue="2% vs last month"
        />
        <StatCard 
          title="Online" 
          value={safeStats.online_boards} 
          icon={CheckCircle} 
          color="bg-emerald-500" 
        />
        <StatCard 
          title="Offline" 
          value={safeStats.offline_boards} 
          icon={AlertCircle} 
          color="bg-rose-500" 
        />
        <StatCard 
          title="Maintenance" 
          value={safeStats.maintenance_boards} 
          icon={Activity} 
          color="bg-amber-500" 
        />
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        {/* System Status Card */}
        <Card 
          title="System Status" 
          subtitle="Core services and worker health"
          className="lg:col-span-2"
        >
          <div className="space-y-6">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="flex items-center gap-4 p-4 rounded-xl bg-slate-50 border border-slate-100 transition-colors hover:bg-slate-100">
                <div className="p-2 bg-emerald-100 rounded-lg">
                  <Wifi className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-xs font-medium text-slate-500 uppercase">Worker Status</p>
                  <p className="text-sm font-semibold text-slate-900">Active & Polling</p>
                </div>
              </div>
              
              <div className="flex items-center gap-4 p-4 rounded-xl bg-slate-50 border border-slate-100 transition-colors hover:bg-slate-100">
                <div className="p-2 bg-indigo-100 rounded-lg">
                  <Network className="w-5 h-5 text-indigo-600" />
                </div>
                <div>
                  <p className="text-xs font-medium text-slate-500 uppercase">Polling Interval</p>
                  <p className="text-sm font-semibold text-slate-900">Every 5 Minutes</p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 rounded-xl bg-slate-50 border border-slate-100 transition-colors hover:bg-slate-100">
                <div className="p-2 bg-emerald-100 rounded-lg">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-xs font-medium text-slate-500 uppercase">Database</p>
                  <p className="text-sm font-semibold text-slate-900">Connected</p>
                </div>
              </div>
            </div>

            <div className="rounded-xl bg-indigo-50 p-4 border border-indigo-100">
              <div className="flex gap-3">
                <Activity className="w-5 h-5 text-indigo-600 flex-shrink-0" />
                <div>
                  <h4 className="text-sm font-semibold text-indigo-900">Network Intelligence</h4>
                  <p className="text-xs text-indigo-700 mt-1 leading-relaxed">
                    System is currently monitoring {safeStats.total_boards} devices across your infrastructure. 
                    Auto-recovery is active for all configured PPPoE and VPN sessions.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Quick Actions / Recent Card */}
        <Card title="Quick Actions">
          <div className="space-y-3">
            <Button variant="outline" className="w-full justify-start text-left">
              <Server className="w-4 h-4 mr-2" />
              Add New Device
            </Button>
            <Button variant="outline" className="w-full justify-start text-left">
              <FileText className="w-4 h-4 mr-2" />
              Generate Report
            </Button>
            <Button variant="outline" className="w-full justify-start text-left">
              <ShieldCheck className="w-4 h-4 mr-2" />
              Security Audit
            </Button>
            <div className="pt-4 border-t border-slate-100">
              <p className="text-xs text-slate-400 text-center italic">
                Last updated: {new Date().toLocaleTimeString()}
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;

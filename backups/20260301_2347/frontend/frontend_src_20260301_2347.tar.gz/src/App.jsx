import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AuthProvider } from './context/AuthContext';
import Layout from './components/layout/Layout';
import ProtectedRoute from './components/ProtectedRoute';
import { Toaster } from 'react-hot-toast';
import LoadingSpinner from './components/ui/LoadingSpinner';

// Create a client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30000, // Data is fresh for 30 seconds
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

// Lazy load pages
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Boards = lazy(() => import('./pages/Boards'));
const RouterDetail = lazy(() => import('./pages/RouterDetail'));
const Reports = lazy(() => import('./pages/Reports'));
const Users = lazy(() => import('./pages/Users'));
const Login = lazy(() => import('./pages/Login'));
const Settings = lazy(() => import('./pages/Settings'));
const AuditLogs = lazy(() => import('./pages/AuditLogs'));
const Automation = lazy(() => import('./pages/Automation'));
const ZTPQueue = lazy(() => import('./pages/ZTPQueue'));
const DeveloperConsole = lazy(() => import('./pages/DeveloperConsole'));

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <AuthProvider>
          <Toaster position="top-right" />
          <Suspense fallback={
            <div className="flex h-screen items-center justify-center bg-slate-50">
              <LoadingSpinner size="lg" />
            </div>
          }>
            <Routes>
              <Route path="/login" element={<Login />} />
              
              <Route path="/" element={
                <ProtectedRoute>
                  <Layout />
                </ProtectedRoute>
              }>
                <Route index element={<Dashboard />} />
                <Route path="boards" element={<Boards />} />
                <Route path="boards/:id" element={<RouterDetail />} />
                <Route path="reports" element={<Reports />} />
                <Route path="users" element={<Users />} />
                <Route path="audit-logs" element={<AuditLogs />} />
                <Route path="settings" element={<Settings />} />
                <Route path="automation" element={<Automation />} />
                <Route path="ztp" element={<ZTPQueue />} />
              </Route>
              
              <Route path="/developer" element={
                <ProtectedRoute>
                  <DeveloperConsole />
                </ProtectedRoute>
              } />
            </Routes>
          </Suspense>
        </AuthProvider>
      </Router>
    </QueryClientProvider>
  );
}

export default App;

import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { login as loginApi, getCurrentUser } from '../services/api';
import toast from 'react-hot-toast';
import { AuthContext } from './useAuth';

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();

  const fetchUser = React.useCallback(async () => {
    try {
      const userData = await getCurrentUser();
      setUser(userData);
      return userData;
    } catch (error) {
      console.error("Failed to fetch user", error);
      localStorage.removeItem('token');
      setUser(null);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    // Check for token in localStorage on init
    const token = localStorage.getItem('token');
    if (token) {
      fetchUser();
    } else {
      setLoading(false);
    }
  }, [fetchUser]);

  const login = React.useCallback(async (username, password) => {
    try {
      const data = await loginApi(username, password);
      if (!data.access_token) {
        throw new Error("No access token received");
      }
      localStorage.setItem('token', data.access_token);
      
      // Fetch full user details immediately
      const userData = await fetchUser();
      
      if (!userData) {
         throw new Error("Failed to retrieve user profile");
      }

      toast.success('Login successful');
      
      // Redirect to where they were trying to go, or home
      const from = location.state?.from?.pathname || '/';
      console.log("Login successful, redirecting to:", from);
      navigate(from, { replace: true });
      return true;
    } catch (error) {
      console.error("Login failed in AuthContext", error);
      
      // Handle Pydantic validation errors (array of objects) or string errors
      let errorMessage = 'Login failed';
      if (error.response?.data?.detail) {
        const detail = error.response.data.detail;
        if (Array.isArray(detail)) {
          // If it's a list (Pydantic validation error), map to a string
          errorMessage = detail.map(err => err.msg).join(', ');
        } else if (typeof detail === 'object') {
          // If it's an object, stringify it
          errorMessage = JSON.stringify(detail);
        } else {
          // If it's a string
          errorMessage = detail;
        }
      }
      
      toast.error(errorMessage);
      return false;
    }
  }, [fetchUser, location, navigate]);

  const logout = React.useCallback(() => {
    localStorage.removeItem('token');
    setUser(null);
    navigate('/login');
    toast.success('Logged out');
  }, [navigate]);

  const value = React.useMemo(() => ({
    user,
    login,
    logout,
    loading
  }), [user, loading, login, logout]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

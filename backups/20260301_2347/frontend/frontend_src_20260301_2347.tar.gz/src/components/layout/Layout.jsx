import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import Sidebar from './Sidebar';
import Navbar from './Navbar';
import Breadcrumbs from '../ui/Breadcrumbs';
import { getDashboardSummary } from '../../services/api';

const Layout = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Check backend status periodically
  const { isError } = useQuery({
    queryKey: ['backendStatus'],
    queryFn: getDashboardSummary,
    refetchInterval: 30000, // Check every 30s
    retry: false,
  });

  const backendStatus = !isError;

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar isSidebarOpen={isSidebarOpen} setIsSidebarOpen={setIsSidebarOpen} />
      
      {/* Main Content Wrapper */}
      <div className="flex flex-1 flex-col overflow-hidden">
        <Navbar toggleSidebar={toggleSidebar} backendStatus={backendStatus} />
        
        {/* Scrollable Area */}
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-slate-50 p-4 sm:p-6 lg:p-8">
          <div className="mx-auto max-w-7xl">
            <Breadcrumbs />
            <div className="mt-4">
              <Outlet />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;

import React from 'react';
import { Menu, LogOut, Bell, Search } from 'lucide-react';
import useAuth from '../../context/useAuth';
import StatusBadge from '../ui/StatusBadge';

const Navbar = ({ toggleSidebar, backendStatus }) => {
  const { logout } = useAuth();

  return (
    <header className="sticky top-0 z-20 flex h-16 flex-shrink-0 items-center gap-x-4 border-b border-slate-200 bg-white px-4 shadow-sm sm:gap-x-6 sm:px-6 lg:px-8">
      {/* Sidebar Toggle (Mobile) */}
      <button 
        type="button" 
        className="-m-2.5 p-2.5 text-slate-700 lg:hidden hover:text-indigo-600 transition-colors" 
        onClick={toggleSidebar}
      >
        <span className="sr-only">Open sidebar</span>
        <Menu className="h-6 w-6" aria-hidden="true" />
      </button>

      {/* Separator */}
      <div className="h-6 w-px bg-slate-200 lg:hidden" aria-hidden="true"></div>

      <div className="flex flex-1 gap-x-4 self-stretch lg:gap-x-6">
        {/* Search / Breadcrumbs Placeholder */}
        <div className="relative flex flex-1 items-center">
           {/* Placeholder for Breadcrumbs or Page Title if managed globally */}
           <div className="text-sm font-medium text-slate-500 hidden sm:block">
             Network Controller Dashboard
           </div>
        </div>

        <div className="flex items-center gap-x-4 lg:gap-x-6">
          {/* Backend Status */}
          <div className="hidden sm:flex items-center">
             <StatusBadge 
                status={backendStatus ? 'online' : 'offline'} 
                className="capitalize"
             />
          </div>

          {/* Notifications */}
          <button type="button" className="-m-2.5 p-2.5 text-slate-400 hover:text-indigo-600 transition-colors">
            <span className="sr-only">View notifications</span>
            <Bell className="h-6 w-6" aria-hidden="true" />
          </button>

          {/* Separator */}
          <div className="hidden lg:block lg:h-6 lg:w-px lg:bg-slate-200" aria-hidden="true"></div>

          {/* User Menu / Logout */}
          <div className="flex items-center gap-2">
             <button
                onClick={logout}
                className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-full transition-colors"
                title="Sign out"
             >
                <LogOut className="w-5 h-5" />
             </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;

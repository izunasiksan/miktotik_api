import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from app.models.mikrotik import MikrotikBoard, BoardEvent
from app.services.telegram_service import telegram_service
from app.core.database import SessionLocal

logger = logging.getLogger("alert_manager")

class AlertManager:
    """
    Manages alerting logic, flapping prevention, and message formatting.
    """
    
    # Store flapping state in memory for now (or Redis in future)
    # Key: board_id, Value: timestamp of first failure
    _offline_candidates: Dict[str, datetime] = {}
    
    # Grace period in seconds before sending alert for offline status
    FLAPPING_GRACE_PERIOD = 60 

    async def check_health(self, session: AsyncSession, board: MikrotikBoard, metrics: Dict[str, Any]):
        """
        Main entry point to check metrics and trigger alerts.
        """
        # 1. Maintenance Check
        if getattr(board, 'is_maintenance', False):
            logger.info(f"Board {board.board_name} is in maintenance. Alerts suppressed.")
            return

        # 2. Offline Detection
        is_online_now = metrics.get('is_online', False)
        
        if not is_online_now:
            await self._handle_offline_event(session, board)
        else:
            await self._handle_recovery_event(session, board)
            
            # 3. High Load Detection (Only if online)
            cpu_load = metrics.get('cpu_load', 0)
            if cpu_load > 90:
                await self._trigger_alert(
                    session, 
                    board, 
                    "warning", 
                    f"⚠️ *HIGH CPU LOAD*\n\nRouter: {board.board_name}\nCPU: {cpu_load}%"
                )

    async def _handle_offline_event(self, session: AsyncSession, board: MikrotikBoard):
        board_id_str = str(board.board_id)
        
        # If already tracked as offline candidate
        if board_id_str in self._offline_candidates:
            first_fail_time = self._offline_candidates[board_id_str]
            duration = (datetime.now() - first_fail_time).total_seconds()
            
            if duration >= self.FLAPPING_GRACE_PERIOD:
                # Confirmed offline (passed grace period)
                # Check if we already sent alert? (Ideally we check last event in DB)
                # For simplicity, we send alert and remove from candidates to avoid spamming every cycle?
                # Better: Check if `is_online` in DB is ALREADY False. If so, don't spam.
                # But here we are processing fresh metrics.
                
                # Logic:
                # If DB says Online, but metrics say Offline > 60s -> Mark Offline in DB, Send Alert.
                if getattr(board, 'is_online', False): 
                    # Update DB status
                    # Note: The caller (polling_worker) usually updates stats, but we update status here?
                    # Let's assume polling_worker updates stats, but we handle status logic.
                    # Wait, polling_worker updates `is_online` based on ping result usually.
                    # Let's assume `board` passed here has the OLD status from DB, and `metrics` has NEW status.
                    
                    logger.warning(f"Board {board.board_name} confirmed OFFLINE after {duration}s.")
                    
                    # Update Board Status in DB
                    stmt = update(MikrotikBoard).where(MikrotikBoard.board_id == board.board_id).values(is_online=False)
                    await session.execute(stmt)
                    await session.commit()
                    
                    # Log Event
                    await self._log_event(session, board, "critical", "Device Offline", f"Device detected offline for > {self.FLAPPING_GRACE_PERIOD}s")
                    
                    # Send Telegram
                    msg = (
                        f"🚨 *ROUTER DOWN*\n\n"
                        f"Nama: {board.board_name}\n"
                        f"Site: {board.site_group}\n"
                        f"Waktu: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                        f"Status: Connection Timed Out"
                    )
                    await telegram_service.send_alert(session, str(board.board_id), msg, "critical")
                    
                    # Clear candidate to reset logic
                    del self._offline_candidates[board_id_str]
        else:
            # First time detecting offline
            logger.warning(f"Board {board.board_name} potential offline detected. Starting grace period.")
            self._offline_candidates[board_id_str] = datetime.now()

    async def _handle_recovery_event(self, session: AsyncSession, board: MikrotikBoard):
        board_id_str = str(board.board_id)
        
        # If it was a candidate, clear it (it flapped back to online)
        if board_id_str in self._offline_candidates:
            logger.info(f"Board {board.board_name} recovered during grace period.")
            del self._offline_candidates[board_id_str]
            return

        # If DB says Offline, but now Online -> Recovery
        is_online_flag = bool(getattr(board, "is_online", False))
        if not is_online_flag:
            logger.info(f"Board {board.board_name} RECOVERED.")
            
            # Update DB
            stmt = update(MikrotikBoard).where(MikrotikBoard.board_id == board.board_id).values(is_online=True)
            await session.execute(stmt)
            await session.commit()
            
            # Log Event
            await self._log_event(session, board, "info", "Device Recovered", "Connection restored")
            
            # Send Telegram
            msg = (
                f"✅ *ROUTER RECOVERED*\n\n"
                f"Nama: {board.board_name}\n"
                f"Site: {board.site_group}\n"
                f"Waktu: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                f"Status: Online"
            )
            await telegram_service.send_alert(session, str(board.board_id), msg, "info")

    async def _trigger_alert(self, session: AsyncSession, board: MikrotikBoard, level: str, message: str):
        # Helper for generic alerts
        await telegram_service.send_alert(session, str(board.board_id), message, level)

    async def _log_event(self, session: AsyncSession, board: MikrotikBoard, level: str, name: str, detail: str):
        event = BoardEvent(
            board_id=board.board_id,
            event_category="system",
            event_level=level,
            event_name=name,
            event_detail=detail
        )
        session.add(event)
        await session.commit()

alert_manager = AlertManager()

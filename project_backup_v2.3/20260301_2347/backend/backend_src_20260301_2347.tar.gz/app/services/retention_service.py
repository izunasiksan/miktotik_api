import os
import logging
import asyncio
from datetime import datetime, timedelta
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import delete, select, text, func
from app.core.database import SessionLocal
from app.models.mikrotik import BoardResourceStat, BoardEvent, BoardBackup

logger = logging.getLogger("retention_service")

async def prune_resource_stats(days_retention: int = 30):
    """
    Menghapus data board_resource_stats yang lebih tua dari days_retention.
    """
    logger.info(f"🧹 Starting resource stats pruning (retention: {days_retention} days)...")
    async with SessionLocal() as db:
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=days_retention)
            stmt = delete(BoardResourceStat).where(BoardResourceStat.log_time < cutoff_date).execution_options(synchronize_session=False)
            result = await db.execute(stmt)
            await db.commit()
            deleted_count = int(getattr(result, "rowcount", 0))
            logger.info(f"✅ Deleted {deleted_count} old resource stats records.")
        except Exception as e:
            await db.rollback()
            logger.error(f"❌ Failed to prune resource stats: {e}")

async def prune_events(days_retention: int = 90):
    """
    Menghapus data board_events yang lebih tua dari days_retention, 
    kecuali event dengan level 'critical' atau 'error'.
    """
    logger.info(f"🧹 Starting events pruning (retention: {days_retention} days)...")
    async with SessionLocal() as db:
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=days_retention)
            # Delete events older than cutoff AND (level != critical AND level != error)
            stmt = delete(BoardEvent).where(
                BoardEvent.log_time < cutoff_date,
                BoardEvent.event_level.not_in(['critical', 'error'])
            ).execution_options(synchronize_session=False)
            result = await db.execute(stmt)
            await db.commit()
            deleted_count = int(getattr(result, "rowcount", 0))
            logger.info(f"✅ Deleted {deleted_count} old event records.")
        except Exception as e:
            await db.rollback()
            logger.error(f"❌ Failed to prune events: {e}")

async def vacuum_database():
    """
    Menjalankan VACUUM ANALYZE untuk mengoptimalkan database.
    Harus dijalankan di luar transaction block (autocommit).
    """
    logger.info("🧹 Starting database vacuum...")
    # Create a dedicated connection for VACUUM since it cannot run inside a transaction block
    # SessionLocal is async, but we need raw connection or special handling
    # SQLAlchemy async session usually wraps in transaction.
    # For VACUUM, we might need to use the engine directly with isolation_level="AUTOCOMMIT"
    
    # Alternative: Just use session execution, but standard session begins transaction automatically.
    # Let's try to use execution_options(isolation_level="AUTOCOMMIT")
    
    async with SessionLocal() as db:
        try:
            # Postgres VACUUM cannot run inside a transaction block
            # We need to ensure we are in autocommit mode
            connection = await db.connection()
            await connection.execution_options(isolation_level="AUTOCOMMIT")
            await connection.execute(text("VACUUM ANALYZE"))
            logger.info("✅ Database vacuum completed.")
        except Exception as e:
            logger.error(f"❌ Failed to vacuum database: {e}")

async def verify_backups():
    """
    Memverifikasi integritas file backup fisik berdasarkan data di database.
    """
    logger.info("🔍 Starting backup integrity check...")
    async with SessionLocal() as db:
        try:
            # Get latest 100 backups to verify (avoid checking thousands of old files)
            stmt = select(BoardBackup).order_by(BoardBackup.log_date.desc()).limit(100)
            result = await db.execute(stmt)
            backups = result.scalars().all()
            
            missing_count = 0
            invalid_size_count = 0
            
            loop = asyncio.get_running_loop()
            
            for backup in backups:
                file_path_val = getattr(backup, "file_location", None)
                file_path = str(file_path_val) if file_path_val is not None else ""
                
                # Use run_in_executor for blocking OS calls
                exists = await loop.run_in_executor(None, os.path.exists, file_path)
                
                if not exists:
                    logger.warning(f"⚠️ Missing backup file: {file_path} (ID: {backup.backup_id})")
                    missing_count += 1
                else:
                    size = await loop.run_in_executor(None, os.path.getsize, file_path)
                    if size == 0:
                        logger.warning(f"⚠️ Empty backup file: {file_path} (ID: {backup.backup_id})")
                        invalid_size_count += 1
            
            logger.info(f"✅ Backup verification done. Missing: {missing_count}, Empty: {invalid_size_count}")
            
        except Exception as e:
            logger.error(f"❌ Failed to verify backups: {e}")

async def run_daily_maintenance():
    """
    Wrapper function untuk dijalankan oleh scheduler (Harian).
    """
    logger.info("🚀 Starting Daily Maintenance Job")
    await verify_backups()
    logger.info("🏁 Daily Maintenance Job Completed")

async def run_weekly_maintenance():
    """
    Wrapper function untuk dijalankan oleh scheduler (Mingguan).
    """
    logger.info("🚀 Starting Weekly Maintenance Job")
    await prune_resource_stats()
    await prune_events()
    # await vacuum_database() # FIXME: Cannot run VACUUM in async session easily without autocommit
    logger.info("🏁 Weekly Maintenance Job Completed")
